from datetime import datetime
now = datetime.now()

print(now)
print(str(now))
print(type(str(now)))